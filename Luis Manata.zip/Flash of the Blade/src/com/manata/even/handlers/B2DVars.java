package com.manata.even.handlers;

public class B2DVars {
	
	public static final float PPM = 100;
	public static final short bit_wall = 2;
	public static final short bit_player = 4;
	public static final short bit_player_ultra = 8;
	public static final short bit_segment = 16;

}